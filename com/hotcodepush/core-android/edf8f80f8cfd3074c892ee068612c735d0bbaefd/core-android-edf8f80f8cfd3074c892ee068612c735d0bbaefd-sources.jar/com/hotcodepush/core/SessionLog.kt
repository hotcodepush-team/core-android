package com.hotcodepush.core

/**
 * One line of this session's log: when, the code from the catalog, and the sentence behind it. The log lives in memory
 * behind the debug screen, never on disk and never on the wire.
 */
data class LogEntry(
    val at: Long,
    val code: String,
    val message: String,
) {
    companion object {
        const val CAPACITY = 200

        /** A cycle's result: the status, the reason and the condition type as the code, the trigger and the release in the sentence. */
        fun ofCycle(
            result: SyncResult,
            trigger: SyncTrigger,
            at: Long,
        ): LogEntry {
            val code = listOfNotNull(result.status.wire, result.reason, result.conditionType?.wire).joinToString(" ")
            return LogEntry(at = at, code = code, message = "${trigger.wire}: ${resolveCycleSentence(result)}")
        }

        // A case table: one line per event type.

        /** An outcome event as it enters the outbox; a check event is the cycle's line already. */
        @Suppress("CyclomaticComplexMethod")
        fun ofDeviceEvent(
            event: DeviceEvent,
            at: Long,
        ): LogEntry? = when (event.type) {
            "downloaded" -> {
                LogEntry(
                    at = at,
                    code = "downloaded",
                    message = "release ${event.releaseId ?: ""}: ${event.downloadSizeBytes ?: 0} bytes as ${event.packKind ?: ""} pack",
                )
            }

            "applied" -> {
                LogEntry(at = at, code = "applied", message = "release ${event.releaseId ?: ""} is the running release")
            }

            "confirmed" -> {
                LogEntry(at = at, code = "confirmed", message = "release ${event.releaseId ?: ""} passed the readiness gate")
            }

            "failed" -> {
                LogEntry(
                    at = at,
                    code = "failed ${event.reason ?: ""}",
                    message =
                    "release ${event.releaseId ?: ""}" + (event.detail?.let { ": $it" } ?: ""),
                )
            }

            else -> {
                null
            }
        }

        fun ofRollback(
            rollback: UpdateRolledBackEvent,
            at: Long,
        ): LogEntry = LogEntry(
            at = at,
            code = "rolled_back",
            message = "release ${rollback.fromRelease.id} rolled back to ${rollback.toRelease?.id ?: "the embedded bundle"}",
        )

        internal fun ofBatch(
            answer: BatchAnswer,
            eventCount: Int,
            at: Long,
        ): LogEntry = when (answer) {
            is BatchAnswer.Acknowledged -> {
                LogEntry(at = at, code = "reported", message = "$eventCount events acknowledged")
            }

            is BatchAnswer.Refused -> {
                LogEntry(at = at, code = "report_refused", message = "$eventCount events dropped: HTTP ${answer.status}")
            }

            is BatchAnswer.Failed -> {
                when (answer.status) {
                    null -> {
                        LogEntry(
                            at = at,
                            code = "report_failed",
                            message = "$eventCount events kept for the next sync: the events endpoint could not be reached",
                        )
                    }

                    else -> {
                        LogEntry(
                            at = at,
                            code = "report_failed",
                            message = "$eventCount events kept for the next sync: HTTP ${answer.status}",
                        )
                    }
                }
            }
        }

        // A case table: one sentence per status.
        @Suppress("CyclomaticComplexMethod")
        private fun resolveCycleSentence(result: SyncResult): String {
            val release = result.release?.let { "release #${it.number} (${it.bundleVersion})" }
            return when (result.status) {
                SyncStatus.UP_TO_DATE -> "${release ?: "the embedded bundle"} is current"
                SyncStatus.AVAILABLE -> "${release ?: "a release"} is available"
                SyncStatus.DOWNLOADED -> "${release ?: "a release"} is downloaded and ${resolveApplySentence(result.applyStrategy)}"
                SyncStatus.APPLIED -> "${release ?: "a release"} is applied and the app reloads"
                SyncStatus.SKIPPED -> "${release ?: "the newest release"} is not taken"
                SyncStatus.FAILED -> result.message ?: ""
            }
        }

        private fun resolveApplySentence(applyStrategy: ApplyStrategy?): String = when (applyStrategy) {
            ApplyStrategy.MANUAL, null -> "waits for applyUpdate()"
            else -> "applies at ${applyStrategy.wire}"
        }
    }
}

/** The log itself, the newest two hundred lines: the core's cycles write it, the debug screen reads it. */
class SessionLog {
    private val entries = ArrayDeque<LogEntry>()

    @Synchronized
    fun record(entry: LogEntry) {
        entries.addLast(entry)
        if (entries.size > LogEntry.CAPACITY) entries.removeFirst()
    }

    @Synchronized
    fun entries(): List<LogEntry> = entries.toList()
}
