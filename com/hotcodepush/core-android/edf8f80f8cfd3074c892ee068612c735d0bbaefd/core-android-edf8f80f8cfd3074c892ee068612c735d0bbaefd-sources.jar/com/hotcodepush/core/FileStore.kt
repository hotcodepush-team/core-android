package com.hotcodepush.core

import android.content.Context
import android.os.Build
import okio.ByteString.Companion.toByteString
import java.io.File
import java.io.InputStream
import java.nio.file.Files
import java.security.DigestInputStream
import java.security.MessageDigest

class HashMismatchException(
    val expected: String,
    val actual: String,
) : Exception("Expected $expected, got $actual")

/** The SDK's directory in the app's private storage: content-addressed files and one manifest per bundle. */
class FileStore(
    val rootDirectory: File,
) {
    val filesDirectory: File get() = File(rootDirectory, "files")
    val bundlesDirectory: File get() = File(rootDirectory, "bundles")

    fun file(sha256: String): File = File(filesDirectory, sha256)

    fun hasFile(sha256: String): Boolean = file(sha256).isFile

    /**
     * Streams the content to a temporary file while hashing it and moves it into place only when it hashes to `sha256`.
     * So a file that exists is complete. The caller closes the stream.
     */
    fun writeFile(
        content: InputStream,
        sha256: String,
    ) {
        filesDirectory.mkdirs()
        val temporary = File(filesDirectory, "$sha256.part")
        try {
            val digest = MessageDigest.getInstance("SHA-256")
            temporary.outputStream().use { output -> DigestInputStream(content, digest).copyTo(output) }
            val actual = digest.digest().toByteString().hex()
            if (actual != sha256) throw HashMismatchException(expected = sha256, actual = actual)
            if (!temporary.renameTo(file(sha256))) temporary.copyTo(file(sha256), overwrite = true)
        } finally {
            temporary.delete()
        }
    }

    fun manifestFile(bundleId: String): File = File(File(bundlesDirectory, bundleId), "manifest.json")

    fun readManifest(bundleId: String): BundleManifest? = manifestFile(bundleId).takeIf { it.isFile }?.let { file ->
        runCatching { BundleManifest.fromJson(org.json.JSONObject(file.readText())) }.getOrNull()
    }

    fun writeManifest(
        manifest: BundleManifest,
        bundleId: String,
    ) {
        val file = manifestFile(bundleId)
        file.parentFile?.mkdirs()
        file.writeText(manifest.toJson().toString())
    }

    fun bundleIds(): List<String> = (bundlesDirectory.list() ?: emptyArray()).filter { readManifest(it) != null }.sorted()

    fun deleteBundle(bundleId: String) {
        File(bundlesDirectory, bundleId).deleteRecursively()
    }

    /** Deletes every file and manifest no kept bundle lists. */
    fun deleteUnusedFiles(keptBundleIds: Set<String>) {
        bundleIds().filter { it !in keptBundleIds }.forEach(::deleteBundle)
        val referenced = keptBundleIds.mapNotNull(::readManifest).flatMap { manifest -> manifest.files.map { it.sha256 } }.toSet()
        (filesDirectory.list() ?: emptyArray()).filter { it !in referenced }.forEach { file(it).delete() }
    }

    fun deleteEverything() {
        rootDirectory.deleteRecursively()
    }

    /** The bytes free on the store's volume, measured on its nearest existing directory. */
    fun availableBytes(): Long = generateSequence(rootDirectory) { it.parentFile }.first { it.exists() }.usableSpace

    /** Whether every file the manifest lists is on disk; existence is the check, not a re-hash. */
    fun isComplete(
        manifest: BundleManifest,
        embedded: EmbeddedBundle,
    ): Boolean = manifest.files.all {
        hasFile(it.sha256) ||
            embedded.has(it.sha256)
    }

    companion object {
        /** Where every SDK keeps its store: `hotcodepush` in the app's private files, under which its loader lays its bundles out too. */
        fun defaultRootDirectory(context: Context): File = File(context.filesDir, "hotcodepush")
    }
}

/** The files compiled into the binary, counted as present by hash; where they are is the platform's. */
interface EmbeddedBundle {
    fun has(sha256: String): Boolean

    /** Copies the embedded file with that hash to the destination. */
    fun copyFile(
        sha256: String,
        destination: File,
    )
}

/** The files compiled into the binary, `assets/<assetDirectory>/` in the APK, addressed by the embedded manifest's hashes; none without a manifest. */
class AssetsEmbeddedBundle(
    private val context: Context,
    manifest: EmbeddedBundleManifest?,
    private val assetDirectory: String,
) : EmbeddedBundle {
    private val pathsBySha256 = manifest?.files.orEmpty().associate { it.sha256 to it.path }

    override fun has(sha256: String): Boolean {
        val path = pathsBySha256[sha256] ?: return false
        return runCatching {
            context.assets.open("$assetDirectory/$path").close()
            true
        }.getOrDefault(false)
    }

    override fun copyFile(
        sha256: String,
        destination: File,
    ) {
        val path = pathsBySha256[sha256] ?: throw PlainException("No embedded file with hash $sha256")
        context.assets.open("$assetDirectory/$path").use { input -> destination.outputStream().use { input.copyTo(it) } }
    }
}

/** Lays a bundle out by path for the WebView, linking to the content-addressed files where the platform allows. */
object BundleProjection {
    // Public API, and the four arguments of core-ios's project(_:from:embedded:into:).
    @Suppress("LongParameterList")
    fun project(
        manifest: BundleManifest,
        files: FileStore,
        embedded: EmbeddedBundle,
        directory: File,
    ) {
        directory.deleteRecursively()
        directory.mkdirs()
        for (file in manifest.files) {
            val destination = File(directory, file.path)
            destination.parentFile?.mkdirs()
            if (files.hasFile(file.sha256)) {
                val source = files.file(file.sha256)
                if (!link(source = source, destination = destination)) source.copyTo(destination, overwrite = true)
            } else {
                embedded.copyFile(file.sha256, destination)
            }
        }
    }

    /** `Files.createLink` arrived with API 26; below it, and wherever a link fails, the tree is a copy. */
    private fun link(
        source: File,
        destination: File,
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        return try {
            Files.createLink(destination.toPath(), source.toPath())
            true
        } catch (exception: Exception) {
            false
        }
    }
}
